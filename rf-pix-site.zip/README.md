# RF — Dados para pagamento

Site estático para **RF — Dados para pagamento**.

## Publicar no GitHub Pages

1. Entre em https://github.com e crie (ou use) sua conta.
2. Clique em **New** para criar um repositório novo chamado **pix** (público).
3. Faça o upload destes arquivos (`index.html` e `favicon.svg`). Você pode arrastar e soltar.
4. Vá em **Settings › Pages**.
5. Em **Build and deployment**, selecione:
   - **Source:** `Deploy from a branch`
   - **Branch:** `main` (ou `master`) e **/root**
   - Clique em **Save**.
6. Aguarde alguns segundos e recarregue a página: o GitHub mostrará o seu link, como:
   - `https://SEU_USUARIO.github.io/pix`

### Dica
- Se quiser usar outro nome (por exemplo, `pagamentos`), renomeie o repositório e o link ficará `https://SEU_USUARIO.github.io/pagamentos`.

---

Gerado automaticamente para publicação rápida.
